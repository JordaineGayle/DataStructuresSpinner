package models.enums;

public enum Categories {
    PERSON,
    PLACE,
    THING,
    PHRASE
}
