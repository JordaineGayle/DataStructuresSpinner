package models.enums;

public enum CardTypes {
    MONEY,
    LOSE_TURN,
    BANKRUPTCY
}
